import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  BookOpen,
  Volume2,
  VolumeX,
  Printer,
  RotateCcw,
  CheckCircle2,
  HelpCircle,
  Lightbulb,
  Clock,
  Layers,
  ArrowRight,
  ArrowLeft,
  Share2,
  Check,
  Bookmark,
} from 'lucide-react';
import {
  SavedLesson,
  Language,
  ActiveTab,
  KeyPoint,
  VocabularyTerm,
} from '../types';
import { translations } from '../i18n';
import { speakText, stopSpeech, isSpeaking } from '../utils/speech';
import { QuizRunner } from './QuizRunner';
import { FlashcardsView } from './FlashcardsView';

interface LessonViewPageProps {
  lesson: SavedLesson;
  lang: Language;
  onUpdateQuizScore: (lessonId: string, score: number, total: number) => void;
  onStartNewLesson: () => void;
  onBackToHome: () => void;
}

export const LessonViewPage: React.FC<LessonViewPageProps> = ({
  lesson,
  lang,
  onUpdateQuizScore,
  onStartNewLesson,
  onBackToHome,
}) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';
  const ArrowIcon = isRtl ? ArrowLeft : ArrowRight;

  const [activeTab, setActiveTab] = useState<ActiveTab>('explanation');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  // Stop audio on unmount or tab change
  useEffect(() => {
    return () => {
      stopSpeech();
    };
  }, []);

  const handleToggleAudio = () => {
    if (isPlayingAudio) {
      stopSpeech();
      setIsPlayingAudio(false);
    } else {
      const fullTextToRead = `${lesson.lessonTitle}. ${lesson.overview}. ${lesson.simpleExplanation}`;
      const started = speakText(
        fullTextToRead,
        lang,
        () => setIsPlayingAudio(false),
        () => setIsPlayingAudio(false)
      );
      if (started) {
        setIsPlayingAudio(true);
      }
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(
        `${lesson.lessonTitle}\n\n${lesson.summary}`
      );
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Top Header Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-7 shadow-sm space-y-4 no-print">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={onBackToHome}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors text-xs font-semibold flex items-center gap-1 cursor-pointer"
            >
              <ArrowIcon className="w-3.5 h-3.5 rotate-180 rtl:rotate-0" />
              <span>{t.backToHome}</span>
            </button>

            <span className="text-xs font-bold px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100">
              {lesson.subjectArea || (lang === 'ar' ? 'درس عام' : 'General')}
            </span>
          </div>

          {/* Quick Action Tools */}
          <div className="flex items-center gap-2">
            <button
              id="audio-read-btn"
              onClick={handleToggleAudio}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                isPlayingAudio
                  ? 'bg-rose-100 text-rose-800 border border-rose-300 animate-pulse'
                  : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-100'
              }`}
            >
              {isPlayingAudio ? (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-rose-600" />
                  <span>{t.stopAudioBtn}</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{t.readAloudBtn}</span>
                </>
              )}
            </button>

            <button
              id="print-lesson-btn"
              onClick={handlePrint}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors text-xs font-semibold flex items-center gap-1 cursor-pointer"
              title={t.printDocBtn}
            >
              <Printer className="w-4 h-4 text-slate-600" />
              <span className="hidden sm:inline">{t.printDocBtn}</span>
            </button>

            <button
              id="share-lesson-btn"
              onClick={handleShare}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors text-xs font-semibold flex items-center gap-1 cursor-pointer"
              title="Copy / Share Summary"
            >
              {isCopied ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Share2 className="w-4 h-4 text-slate-600" />
              )}
            </button>
          </div>
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-tight">
            {lesson.lessonTitle}
          </h1>

          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              {lesson.estimatedReadingTimeMinutes || 4} {t.minutesRead}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
              {lesson.quiz.length} {lang === 'ar' ? 'أسئلة اختبار' : 'Quiz Questions'}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Layers className="w-3.5 h-3.5 text-slate-400" />
              {lesson.flashcards.length} {lang === 'ar' ? 'بطاقات حفظ' : 'Flashcards'}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs Navigation Bar */}
      <div className="no-print bg-slate-100 p-1.5 rounded-2xl border border-slate-200 flex overflow-x-auto gap-1">
        <button
          id="tab-explanation-btn"
          onClick={() => setActiveTab('explanation')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeTab === 'explanation'
              ? 'bg-white text-indigo-700 shadow-sm border border-slate-200/50'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>{t.tabExplanation}</span>
        </button>

        <button
          id="tab-summary-btn"
          onClick={() => setActiveTab('summary')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeTab === 'summary'
              ? 'bg-white text-indigo-700 shadow-sm border border-slate-200/50'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>{t.tabSummary}</span>
        </button>

        <button
          id="tab-flashcards-btn"
          onClick={() => setActiveTab('flashcards')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeTab === 'flashcards'
              ? 'bg-white text-indigo-700 shadow-sm border border-slate-200/50'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>{t.tabFlashcards}</span>
        </button>

        <button
          id="tab-quiz-btn"
          onClick={() => setActiveTab('quiz')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeTab === 'quiz'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>{t.tabQuiz}</span>
          {lesson.lastQuizScore && (
            <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-bold ${
              activeTab === 'quiz' ? 'bg-indigo-800 text-indigo-100' : 'bg-indigo-100 text-indigo-800'
            }`}>
              {lesson.lastQuizScore.percentage}%
            </span>
          )}
        </button>
      </div>

      {/* Tab 1: Simple Explanation */}
      {activeTab === 'explanation' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Friendly Overview */}
          <div className="bg-indigo-50/60 border border-indigo-100 rounded-3xl p-6 sm:p-7 space-y-2">
            <h2 className="text-sm sm:text-base font-bold text-indigo-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>{t.overviewTitle}</span>
            </h2>
            <p className="text-slate-800 text-sm sm:text-base leading-relaxed">
              {lesson.overview}
            </p>
          </div>

          {/* Simplified conversational explanation */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-4 shadow-sm">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
              <span className="w-2 h-6 bg-indigo-500 rounded-full inline-block"></span>
              <span>{t.simpleExplanationTitle}</span>
            </h2>

            <div className="prose prose-slate max-w-none text-sm sm:text-base leading-relaxed text-slate-700 whitespace-pre-line space-y-4">
              {lesson.simpleExplanation}
            </div>
          </div>

          {/* Detailed Section Breakdown */}
          {lesson.detailedSections && lesson.detailedSections.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-indigo-600" />
                <span>{t.detailedBreakdownTitle}</span>
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {lesson.detailedSections.map((sec, idx) => (
                  <div
                    key={idx}
                    className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3 shadow-sm hover:border-indigo-300 transition-all flex flex-col justify-between"
                  >
                    <div className="space-y-2">
                      <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center text-xs font-bold shrink-0 border border-indigo-100">
                          {idx + 1}
                        </span>
                        <span>{sec.title}</span>
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed whitespace-pre-line">
                        {sec.content}
                      </p>
                    </div>

                    <div className="bg-amber-50 rounded-xl p-3 border border-amber-200 text-xs text-amber-900 space-y-0.5">
                      <span className="font-bold block">
                        {t.keyTakeawayLabel}
                      </span>
                      <span>{sec.keyTakeaway}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Study Tips Box */}
          {lesson.studyTips && lesson.studyTips.length > 0 && (
            <div className="bg-emerald-50/70 border border-emerald-200 rounded-3xl p-6 space-y-3">
              <h2 className="text-sm sm:text-base font-bold text-emerald-950 flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-emerald-600" />
                <span>{t.studyTipsTitle}</span>
              </h2>
              <ul className="space-y-2">
                {lesson.studyTips.map((tip, idx) => (
                  <li
                    key={idx}
                    className="text-xs sm:text-sm text-emerald-900 flex items-start gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* CTA to take quiz */}
          <div className="p-6 sm:p-8 rounded-3xl bg-indigo-900 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-md relative overflow-hidden">
            <div className="relative z-10 space-y-1 text-center sm:text-right rtl:sm:text-right ltr:sm:text-left">
              <h3 className="font-bold text-base sm:text-lg text-white">
                {lang === 'ar'
                  ? 'جاهز لاختبار مدى فهمك؟'
                  : 'Ready to test your knowledge?'}
              </h3>
              <p className="text-xs sm:text-sm text-indigo-200">
                {lang === 'ar'
                  ? 'أجب على الاختبار التفاعلي لتحصل على تقييم وتفسير فوري.'
                  : 'Take the multiple-choice quiz for instant score & feedback.'}
              </p>
            </div>
            <button
              onClick={() => setActiveTab('quiz')}
              className="relative z-10 px-6 py-3 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white font-bold text-xs sm:text-sm transition-all shadow-lg flex items-center gap-2 shrink-0 cursor-pointer active:scale-95"
            >
              <span>{t.startQuizBtn}</span>
              <ArrowIcon className="w-4 h-4" />
            </button>
            <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-white/10 rounded-full blur-2xl pointer-events-none"></div>
          </div>
        </div>
      )}

      {/* Tab 2: Summary & Key Points */}
      {activeTab === 'summary' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Executive Summary Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-4 shadow-sm">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
              <span className="w-2 h-6 bg-indigo-500 rounded-full inline-block"></span>
              <span>{t.summaryTitle}</span>
            </h2>
            <div className="text-sm sm:text-base text-slate-700 leading-relaxed whitespace-pre-line bg-slate-50 p-5 rounded-2xl border border-slate-200">
              {lesson.summary}
            </div>
          </div>

          {/* Key Priority Points */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-4 shadow-sm">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
              <span className="w-2 h-6 bg-indigo-500 rounded-full inline-block"></span>
              <span>{t.keyPointsTitle}</span>
            </h2>

            <div className="space-y-3">
              {lesson.keyPoints.map((kp, idx) => (
                <div
                  key={kp.id || idx}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-start gap-3"
                >
                  <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                    {idx + 1}
                  </span>

                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs sm:text-sm font-bold text-slate-900 leading-snug">
                        {kp.point}
                      </p>
                      <span
                        className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full shrink-0 ${
                          kp.importance === 'high'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-indigo-100 text-indigo-800'
                        }`}
                      >
                        {kp.importance === 'high'
                          ? t.importanceHigh
                          : t.importanceMedium}
                      </span>
                    </div>
                    {kp.category && (
                      <span className="text-[11px] text-slate-500 block">
                        {kp.category}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Vocabulary & Terminology */}
          {lesson.vocabulary && lesson.vocabulary.length > 0 && (
            <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-4 shadow-sm">
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
                <span className="w-2 h-6 bg-indigo-500 rounded-full inline-block"></span>
                <span>{t.vocabularyTitle}</span>
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {lesson.vocabulary.map((v, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200 space-y-2 hover:border-indigo-300 transition-colors"
                  >
                    <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-indigo-500" />
                      <span>{v.term}</span>
                    </h3>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      <strong className="text-slate-700">
                        {t.termDefinitionLabel}{' '}
                      </strong>
                      {v.definition}
                    </p>
                    {v.example && (
                      <p className="text-xs text-slate-500 bg-white p-2 rounded-xl border border-slate-200/80">
                        <strong>{t.termExampleLabel} </strong>
                        {v.example}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Flashcards */}
      {activeTab === 'flashcards' && (
        <div className="animate-in fade-in duration-200 py-2">
          <FlashcardsView
            initialFlashcards={lesson.flashcards}
            lang={lang}
          />
        </div>
      )}

      {/* Tab 4: Interactive Quiz */}
      {activeTab === 'quiz' && (
        <div className="animate-in fade-in duration-200 py-2">
          <QuizRunner
            questions={lesson.quiz}
            lang={lang}
            lessonTitle={lesson.lessonTitle}
            onQuizCompleted={(score, total) => {
              onUpdateQuizScore(lesson.id, score, total);
            }}
          />
        </div>
      )}

      {/* Printable Study Sheet (Visible on Print or when print is triggered) */}
      <div className="hidden print:block space-y-6 pt-4 text-black bg-white">
        <div className="border-b pb-4 text-center space-y-1">
          <h1 className="text-2xl font-bold">{lesson.lessonTitle}</h1>
          <p className="text-xs text-gray-500">
            QuizMaster Hub • {lesson.subjectArea} • {new Date().toLocaleDateString()}
          </p>
        </div>

        <div className="space-y-2">
          <h2 className="text-lg font-bold border-b pb-1">ملخص الدرس / Summary</h2>
          <p className="text-sm leading-relaxed">{lesson.summary}</p>
        </div>

        <div className="space-y-2">
          <h2 className="text-lg font-bold border-b pb-1">أهم النقاط / Key Points</h2>
          <ul className="list-disc pl-5 rtl:pr-5 space-y-1 text-sm">
            {lesson.keyPoints.map((kp, i) => (
              <li key={i}>{kp.point}</li>
            ))}
          </ul>
        </div>

        <div className="space-y-3 pt-2">
          <h2 className="text-lg font-bold border-b pb-1">أسئلة الاختبار / Quiz Questions</h2>
          {lesson.quiz.map((q, i) => (
            <div key={i} className="space-y-1 text-sm border p-2 rounded">
              <p className="font-bold">
                {i + 1}. {q.question}
              </p>
              <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                {q.options.map((opt, oIdx) => (
                  <div key={oIdx}>
                    ({['أ', 'ب', 'ج', 'د'][oIdx]}) {opt}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
