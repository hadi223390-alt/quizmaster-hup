import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  Trash2,
  Clock,
  Award,
  ArrowRight,
  ArrowLeft,
  PlusCircle,
  HelpCircle,
  Layers,
  FileText,
} from 'lucide-react';
import { SavedLesson, Language } from '../types';
import { translations } from '../i18n';

interface SavedLessonsPageProps {
  lang: Language;
  savedLessons: SavedLesson[];
  onSelectLesson: (lesson: SavedLesson) => void;
  onDeleteLesson: (id: string) => void;
  onStartNewLesson: () => void;
}

export const SavedLessonsPage: React.FC<SavedLessonsPageProps> = ({
  lang,
  savedLessons,
  onSelectLesson,
  onDeleteLesson,
  onStartNewLesson,
}) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';
  const ArrowIcon = isRtl ? ArrowLeft : ArrowRight;

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');

  // Extract unique subjects
  const subjects = Array.from(
    new Set(savedLessons.map((l) => l.subjectArea || 'عام'))
  );

  const filteredLessons = savedLessons.filter((lesson) => {
    const matchesSearch =
      lesson.lessonTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lesson.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (lesson.subjectArea &&
        lesson.subjectArea.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesSubject =
      selectedSubject === 'all' || lesson.subjectArea === selectedSubject;

    return matchesSearch && matchesSubject;
  });

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            {t.navSavedLessons}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            {lang === 'ar'
              ? 'مكتبتك الدراسية لجميع الدروس التي تم تلخيصها واختبارها'
              : 'Your personal library of analyzed lessons and quizzes'}
          </p>
        </div>

        <button
          id="saved-page-new-lesson-btn"
          onClick={onStartNewLesson}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm transition-all flex items-center gap-2 shadow-md shadow-indigo-600/20 cursor-pointer active:scale-95"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{t.startNowBtn}</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      {savedLessons.length > 0 && (
        <div className="flex flex-col sm:flex-row items-center gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-sm">
          {/* Search Input */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 left-3 rtl:left-auto rtl:right-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                lang === 'ar'
                  ? 'ابحث في عناوين الدروس أو الملخصات...'
                  : 'Search lesson titles or summaries...'
              }
              className="w-full pl-9 pr-4 rtl:pl-4 rtl:pr-9 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          {/* Subject Filter Pills */}
          {subjects.length > 1 && (
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto py-1">
              <button
                onClick={() => setSelectedSubject('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedSubject === 'all'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {lang === 'ar' ? 'الكل' : 'All'}
              </button>
              {subjects.map((sub) => (
                <button
                  key={sub}
                  onClick={() => setSelectedSubject(sub)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                    selectedSubject === sub
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {sub}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Grid of Saved Lessons */}
      {filteredLessons.length === 0 ? (
        <div className="text-center py-16 px-4 rounded-3xl bg-white border border-slate-200 space-y-4 shadow-sm">
          <div className="w-14 h-14 rounded-2xl bg-indigo-50 text-indigo-600 mx-auto flex items-center justify-center border border-indigo-100">
            <FileText className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <p className="font-bold text-slate-800 text-base">
              {searchQuery
                ? lang === 'ar'
                  ? 'لم يتم العثور على أي درس مطابق للبحث'
                  : 'No lessons matched your search'
                : t.noRecentLessons}
            </p>
          </div>
          <button
            onClick={onStartNewLesson}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-xs transition-colors cursor-pointer shadow-md shadow-indigo-600/20 active:scale-95"
          >
            <span>{t.startNowBtn}</span>
            <ArrowIcon className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredLessons.map((lesson) => (
            <div
              key={lesson.id}
              className="bg-white rounded-2xl border border-slate-200 hover:border-indigo-400 hover:shadow-md transition-all p-5 flex flex-col justify-between space-y-4 relative group"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100">
                    {lesson.subjectArea ||
                      (lang === 'ar' ? 'درس عام' : 'General')}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {lesson.estimatedReadingTimeMinutes || 4} {t.minutesRead}
                    </span>
                    <button
                      id={`delete-history-${lesson.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (window.confirm(t.confirmDelete)) {
                          onDeleteLesson(lesson.id);
                        }
                      }}
                      className="p-1 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                      title={t.deleteLessonBtn}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <h3 className="font-bold text-slate-900 text-base leading-snug line-clamp-1 group-hover:text-indigo-600 transition-colors">
                  {lesson.lessonTitle}
                </h3>

                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                  {lesson.overview || lesson.summary}
                </p>

                {/* Score badge & quick specs */}
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100 text-xs">
                  <span className="text-slate-500 font-medium">
                    {lesson.quiz.length} {lang === 'ar' ? 'أسئلة' : 'Q’s'} •{' '}
                    {lesson.flashcards.length}{' '}
                    {lang === 'ar' ? 'بطاقة' : 'Cards'}
                  </span>
                  {lesson.lastQuizScore ? (
                    <span
                      className={`font-bold ${
                        lesson.lastQuizScore.percentage >= 80
                          ? 'text-emerald-700'
                          : lesson.lastQuizScore.percentage >= 50
                          ? 'text-indigo-700'
                          : 'text-rose-700'
                      }`}
                    >
                      {lesson.lastQuizScore.score}/{lesson.lastQuizScore.total} (
                      {lesson.lastQuizScore.percentage}%)
                    </span>
                  ) : (
                    <span className="text-[11px] text-slate-400">
                      {lang === 'ar' ? 'لم يُختبر' : 'No quiz yet'}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                <button
                  id={`open-history-btn-${lesson.id}`}
                  onClick={() => onSelectLesson(lesson)}
                  className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-indigo-600/20 active:scale-95"
                >
                  <span>{t.viewLessonBtn}</span>
                  <ArrowIcon className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
