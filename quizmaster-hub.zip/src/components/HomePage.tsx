import React from 'react';
import {
  Sparkles,
  BookOpen,
  HelpCircle,
  Layers,
  ArrowRight,
  ArrowLeft,
  Flame,
  Award,
  Clock,
  Trash2,
  PlayCircle,
  FileText,
  Camera,
  CheckCircle2,
} from 'lucide-react';
import { Language, SavedLesson } from '../types';
import { translations } from '../i18n';
import { SAMPLE_PRESETS, SamplePreset } from '../sampleLessons';

interface HomePageProps {
  lang: Language;
  savedLessons: SavedLesson[];
  onStartNewLesson: () => void;
  onSelectLesson: (lesson: SavedLesson) => void;
  onDeleteLesson: (id: string) => void;
  onSelectSamplePreset: (preset: SamplePreset) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  lang,
  savedLessons,
  onStartNewLesson,
  onSelectLesson,
  onDeleteLesson,
  onSelectSamplePreset,
}) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';
  const ArrowIcon = isRtl ? ArrowLeft : ArrowRight;

  // Compute summary stats
  const totalLessons = savedLessons.length;
  const totalQuizzes = savedLessons.reduce(
    (acc, l) => acc + (l.quizCompletedCount || 0),
    0
  );
  const quizScores = savedLessons
    .filter((l) => l.lastQuizScore?.percentage !== undefined)
    .map((l) => l.lastQuizScore!.percentage);
  const avgScore =
    quizScores.length > 0
      ? Math.round(quizScores.reduce((a, b) => a + b, 0) / quizScores.length)
      : null;

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-indigo-500/10 via-indigo-500/5 to-transparent border border-indigo-100 p-6 sm:p-10 lg:p-12">
        <div className="max-w-3xl space-y-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
            <span>{t.appTagline}</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-indigo-950 leading-tight tracking-tight">
            {t.welcomeTitle}
          </h1>

          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            {t.welcomeSubtitle}
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              id="hero-start-btn"
              onClick={onStartNewLesson}
              className="px-6 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-base shadow-lg shadow-indigo-200 hover:shadow-indigo-300 active:scale-95 transition-all flex items-center gap-2 group cursor-pointer"
            >
              <span>{t.startNowBtn}</span>
              <ArrowIcon className="w-5 h-5 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
            </button>

            {savedLessons.length > 0 && (
              <a
                href="#recent-lessons"
                className="px-5 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-semibold text-base border border-slate-200 shadow-sm transition-all"
              >
                {t.browseHistoryBtn} ({savedLessons.length})
              </a>
            )}
          </div>
        </div>

        {/* Floating Stat Counters */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4 mt-8 pt-8 border-t border-indigo-100">
          <div className="bg-white/90 backdrop-blur-sm p-4 rounded-2xl border border-slate-100 shadow-sm">
            <div className="flex items-center gap-2 text-slate-500 text-xs sm:text-sm font-medium mb-1">
              <BookOpen className="w-4 h-4 text-indigo-600" />
              <span>{t.statsLessons}</span>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {totalLessons}
            </div>
          </div>

          <div className="bg-white/90 backdrop-blur-sm p-4 rounded-2xl border border-slate-100 shadow-sm">
            <div className="flex items-center gap-2 text-slate-500 text-xs sm:text-sm font-medium mb-1">
              <HelpCircle className="w-4 h-4 text-emerald-600" />
              <span>{t.statsQuizzes}</span>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {totalQuizzes}
            </div>
          </div>

          <div className="col-span-2 sm:col-span-1 bg-white/90 backdrop-blur-sm p-4 rounded-2xl border border-slate-100 shadow-sm">
            <div className="flex items-center gap-2 text-slate-500 text-xs sm:text-sm font-medium mb-1">
              <Award className="w-4 h-4 text-amber-500" />
              <span>{t.statsAvgScore}</span>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {avgScore !== null ? `${avgScore}%` : '—'}
            </div>
          </div>
        </div>
      </section>

      {/* Feature Pillars */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
            {t.featuresTitle}
          </h2>
          <p className="text-slate-600 text-sm sm:text-base">
            {lang === 'ar'
              ? 'كل ما يحتاجه الطالب للتحضير السريع والعميق لأي اختبار مدرسي أو جامعي'
              : 'Everything a student needs for quick, deep, and confident exam revision'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm hover:border-indigo-300 transition-all space-y-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xl">
              💡
            </div>
            <h3 className="font-bold text-base text-slate-900">
              {t.featureExplainTitle}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {t.featureExplainDesc}
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm hover:border-sky-300 transition-all space-y-3">
            <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center font-bold text-xl">
              📑
            </div>
            <h3 className="font-bold text-base text-slate-900">
              {t.featureSummaryTitle}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {t.featureSummaryDesc}
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm hover:border-emerald-300 transition-all space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xl">
              🎯
            </div>
            <h3 className="font-bold text-base text-slate-900">
              {t.featureQuizTitle}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {t.featureQuizDesc}
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm hover:border-purple-300 transition-all space-y-3">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold text-xl">
              📇
            </div>
            <h3 className="font-bold text-base text-slate-900">
              {t.featureFlashcardsTitle}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {t.featureFlashcardsDesc}
            </p>
          </div>
        </div>
      </section>

      {/* Quick-Start Sample Lessons */}
      <section className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 space-y-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
              <span className="w-2 h-6 bg-indigo-500 rounded-full inline-block"></span>
              <span>{t.sampleLessonsTitle}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              {lang === 'ar'
                ? 'انقر على أي نموذج لتجربة التحليل الفوري وتوليد الاختبار فوراً'
                : 'Click any sample to test instant analysis and quiz generation'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {SAMPLE_PRESETS.map((preset) => (
            <div
              key={preset.id}
              className="bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-indigo-400 hover:bg-white hover:shadow-md transition-all flex flex-col justify-between space-y-4 group"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-2xl">{preset.icon}</span>
                  <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100">
                    {lang === 'ar' ? preset.subjectAr : preset.subjectEn}
                  </span>
                </div>
                <h3 className="font-bold text-slate-900 text-base group-hover:text-indigo-600 transition-colors">
                  {lang === 'ar' ? preset.titleAr : preset.titleEn}
                </h3>
                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                  {lang === 'ar' ? preset.contentAr : preset.contentEn}
                </p>
              </div>

              <button
                id={`sample-preset-${preset.id}`}
                onClick={() => onSelectSamplePreset(preset)}
                className="w-full py-2.5 px-3 rounded-xl bg-indigo-50 hover:bg-indigo-600 hover:text-white text-indigo-700 font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-indigo-100"
              >
                <span>{t.trySampleBtn}</span>
                <ArrowIcon className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Tip Banner */}
      <section className="bg-indigo-900 rounded-2xl p-6 text-white overflow-hidden relative shadow-md">
        <div className="relative z-10 max-w-2xl space-y-1.5">
          <h3 className="text-base sm:text-lg font-bold flex items-center gap-2">
            <span>💡</span>
            <span>{lang === 'ar' ? 'نصيحة للمذاكرة الفعالة' : 'Study Tip for Maximum Retention'}</span>
          </h3>
          <p className="text-xs sm:text-sm text-indigo-200 leading-relaxed">
            {lang === 'ar'
              ? 'تقسيم وقت الدراسة إلى جلسات مدتها 25 دقيقة (تقنية بومودورو) تليها استراحة 5 دقائق يعزز من قدرة الدماغ على استرجاع المعلومات بنسبة 40%.'
              : 'Breaking your study time into 25-minute Pomodoro sessions followed by quick quizzes boosts memory recall and active retention by up to 40%.'}
          </p>
        </div>
        <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-white/10 rounded-full blur-2xl pointer-events-none"></div>
      </section>

      {/* Recent Studied Lessons */}
      <section id="recent-lessons" className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <span className="w-2 h-6 bg-indigo-500 rounded-full inline-block"></span>
            <span>{t.recentLessonsTitle}</span>
          </h2>
          {savedLessons.length > 0 && (
            <span className="text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 px-3 py-1 rounded-full">
              {savedLessons.length} {lang === 'ar' ? 'دروس' : 'lessons'}
            </span>
          )}
        </div>

        {savedLessons.length === 0 ? (
          <div className="text-center py-12 px-4 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-indigo-50 text-indigo-600 mx-auto flex items-center justify-center">
              <FileText className="w-7 h-7" />
            </div>
            <div className="space-y-1">
              <p className="font-bold text-slate-800 text-base">
                {t.noRecentLessons}
              </p>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {lang === 'ar'
                  ? 'الصق نص أي مادة دراسية أو صور صفحة من كتابك وابدأ المذاكرة الذكية الآن.'
                  : 'Paste any lesson notes or snap a photo of your book page to begin.'}
              </p>
            </div>
            <button
              id="empty-start-lesson-btn"
              onClick={onStartNewLesson}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-md shadow-indigo-200 transition-all cursor-pointer"
            >
              <span>{t.startNowBtn}</span>
              <ArrowIcon className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {savedLessons.map((lesson) => (
              <div
                key={lesson.id}
                className="bg-white rounded-2xl border border-slate-200 hover:border-indigo-400 hover:shadow-md transition-all p-5 flex flex-col justify-between space-y-4 relative group"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100">
                      {lesson.subjectArea ||
                        (lang === 'ar' ? 'درس عام' : 'General')}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {lesson.estimatedReadingTimeMinutes || 3} {t.minutesRead}
                      </span>
                      <button
                        id={`delete-lesson-${lesson.id}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (window.confirm(t.confirmDelete)) {
                            onDeleteLesson(lesson.id);
                          }
                        }}
                        className="p-1 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                        title={t.deleteLessonBtn}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <h3 className="font-bold text-slate-900 text-base leading-snug line-clamp-1 group-hover:text-indigo-600 transition-colors">
                    {lesson.lessonTitle}
                  </h3>

                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {lesson.overview || lesson.summary}
                  </p>

                  {/* Quiz Score Badge */}
                  {lesson.lastQuizScore && (
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs">
                      <span className="text-slate-500 font-medium">
                        {t.quizTitle}:
                      </span>
                      <span
                        className={`font-bold ${
                          lesson.lastQuizScore.percentage >= 80
                            ? 'text-emerald-600'
                            : lesson.lastQuizScore.percentage >= 50
                            ? 'text-amber-600'
                            : 'text-rose-600'
                        }`}
                      >
                        {lesson.lastQuizScore.score}/{lesson.lastQuizScore.total} (
                        {lesson.lastQuizScore.percentage}%)
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                  <button
                    id={`open-lesson-${lesson.id}`}
                    onClick={() => onSelectLesson(lesson)}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-sm shadow-indigo-200 cursor-pointer"
                  >
                    <span>{t.viewLessonBtn}</span>
                    <ArrowIcon className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
