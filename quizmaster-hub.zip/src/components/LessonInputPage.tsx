import React, { useState, useRef } from 'react';
import {
  Sparkles,
  UploadCloud,
  FileText,
  Image as ImageIcon,
  X,
  AlertCircle,
  CheckCircle2,
  Wand2,
  ChevronDown,
  RotateCcw,
  BookOpen,
} from 'lucide-react';
import {
  Language,
  GradeLevel,
  QuizDifficulty,
  LessonAnalysisResult,
} from '../types';
import { translations } from '../i18n';
import { SAMPLE_PRESETS } from '../sampleLessons';

interface LessonInputPageProps {
  lang: Language;
  onAnalysisComplete: (
    result: LessonAnalysisResult,
    meta: {
      title: string;
      inputType: 'text' | 'image';
      targetLanguage: Language;
      sourceSnippet: string;
    }
  ) => void;
  initialPresetText?: string;
  initialPresetTitle?: string;
}

export const LessonInputPage: React.FC<LessonInputPageProps> = ({
  lang,
  onAnalysisComplete,
  initialPresetText = '',
  initialPresetTitle = '',
}) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';

  const [inputMode, setInputMode] = useState<'text' | 'image'>('text');
  const [lessonTitle, setLessonTitle] = useState(initialPresetTitle);
  const [lessonText, setLessonText] = useState(initialPresetText);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imageFileName, setImageFileName] = useState<string>('');
  const [imageMimeType, setImageMimeType] = useState<string>('image/jpeg');

  // Customization settings
  const [gradeLevel, setGradeLevel] = useState<GradeLevel>('intermediate');
  const [difficulty, setDifficulty] = useState<QuizDifficulty>('medium');
  const [questionCount, setQuestionCount] = useState<number>(5);
  const [targetLang, setTargetLang] = useState<Language>(lang);

  // Loading & Error States
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(1);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  // Handle image upload & file conversion
  const processFile = (file: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setErrorMessage(
        lang === 'ar'
          ? 'يرجى اختيار ملف صورة صالح (PNG, JPG, WEBP).'
          : 'Please select a valid image file (PNG, JPG, WEBP).'
      );
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      setErrorMessage(
        lang === 'ar'
          ? 'حجم الصورة كبير جداً، يرجى اختيار صورة أقل من 15 ميجابايت.'
          : 'Image file size is too large (must be under 15MB).'
      );
      return;
    }

    setImageFileName(file.name);
    setImageMimeType(file.type);
    setErrorMessage(null);

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setImageBase64(result);
    };
    reader.onerror = () => {
      setErrorMessage(
        lang === 'ar'
          ? 'تعذر قراءة ملف الصورة. حاول مرة أخرى.'
          : 'Failed to read image file. Please try again.'
      );
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  // Submit and analyze
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (inputMode === 'text' && !lessonText.trim()) {
      setErrorMessage(
        lang === 'ar'
          ? 'يرجى كتابة أو لصق نص الدرس أولاً.'
          : 'Please enter or paste lesson text first.'
      );
      return;
    }

    if (inputMode === 'image' && !imageBase64) {
      setErrorMessage(
        lang === 'ar'
          ? 'يرجى رفع صورة لصفحة الدرس أولاً.'
          : 'Please upload a photo of the lesson page first.'
      );
      return;
    }

    setIsLoading(true);
    setLoadingStep(1);

    // Dynamic step simulator for visual reassurance
    const timer1 = setTimeout(() => setLoadingStep(2), 2200);
    const timer2 = setTimeout(() => setLoadingStep(3), 4800);
    const timer3 = setTimeout(() => setLoadingStep(4), 7200);

    try {
      const payload = {
        title: lessonTitle.trim(),
        text: inputMode === 'text' ? lessonText.trim() : '',
        imageBase64: inputMode === 'image' ? imageBase64 : '',
        mimeType: imageMimeType,
        language: targetLang,
        gradeLevel,
        difficulty,
        questionCount,
      };

      const response = await fetch('/api/analyze-lesson', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(
          errData.error ||
            (lang === 'ar'
              ? 'حدث خطأ أثناء تحليل الدرس بالذكاء الاصطناعي.'
              : 'Failed to analyze lesson with AI.')
        );
      }

      const data: LessonAnalysisResult = await response.json();

      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);

      const snippet =
        inputMode === 'text'
          ? lessonText.slice(0, 120) + '...'
          : `[صورة صفحة]: ${imageFileName}`;

      onAnalysisComplete(data, {
        title: lessonTitle.trim() || data.lessonTitle,
        inputType: inputMode,
        targetLanguage: targetLang,
        sourceSnippet: snippet,
      });
    } catch (err: any) {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      console.error('Analysis error:', err);
      setErrorMessage(err.message || t.errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFillSample = (sampleText: string, sampleTitle: string) => {
    setInputMode('text');
    setLessonTitle(sampleTitle);
    setLessonText(sampleText);
    setErrorMessage(null);
  };

  const handleClear = () => {
    setLessonTitle('');
    setLessonText('');
    setImageBase64(null);
    setImageFileName('');
    setErrorMessage(null);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-16">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
          {t.inputPageTitle}
        </h1>
        <p className="text-slate-600 text-sm sm:text-base max-w-xl mx-auto">
          {t.inputPageSubtitle}
        </p>
      </div>

      {/* Main Input Card */}
      <form
        onSubmit={handleSubmit}
        className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6"
      >
        {/* Lesson Title Field */}
        <div className="space-y-1.5">
          <label
            htmlFor="lesson-title-input"
            className="block text-xs sm:text-sm font-bold text-slate-800"
          >
            {t.lessonTitleLabel}
          </label>
          <input
            id="lesson-title-input"
            type="text"
            value={lessonTitle}
            onChange={(e) => setLessonTitle(e.target.value)}
            placeholder={t.lessonTitlePlaceholder}
            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 text-slate-900 placeholder:text-slate-400 text-sm outline-none transition-all"
          />
        </div>

        {/* Input Mode Switcher Tabs */}
        <div className="space-y-3">
          <div className="flex rounded-2xl bg-slate-100 p-1.5 gap-1 border border-slate-200">
            <button
              type="button"
              id="input-mode-text-btn"
              onClick={() => setInputMode('text')}
              className={`flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                inputMode === 'text'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <FileText className="w-4 h-4 text-indigo-600" />
              <span>{t.tabPasteText}</span>
            </button>

            <button
              type="button"
              id="input-mode-image-btn"
              onClick={() => setInputMode('image')}
              className={`flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                inputMode === 'image'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <ImageIcon className="w-4 h-4 text-indigo-600" />
              <span>{t.tabUploadImage}</span>
            </button>
          </div>

          {/* Mode 1: Paste Text */}
          {inputMode === 'text' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label
                  htmlFor="lesson-text-input"
                  className="block text-xs sm:text-sm font-bold text-slate-800"
                >
                  {t.pasteTextLabel}
                </label>
                {/* Sample Fillers */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-slate-400 hidden sm:inline">
                    {lang === 'ar' ? 'نماذج جاهزة:' : 'Sample topics:'}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      handleFillSample(
                        SAMPLE_PRESETS[0].contentAr,
                        SAMPLE_PRESETS[0].titleAr
                      )
                    }
                    className="text-[11px] px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-semibold transition-colors cursor-pointer border border-indigo-100"
                  >
                    🌱 {lang === 'ar' ? 'أحياء' : 'Biology'}
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      handleFillSample(
                        SAMPLE_PRESETS[1].contentAr,
                        SAMPLE_PRESETS[1].titleAr
                      )
                    }
                    className="text-[11px] px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 font-semibold transition-colors cursor-pointer border border-sky-100"
                  >
                    ⚡ {lang === 'ar' ? 'فيزياء' : 'Physics'}
                  </button>
                </div>
              </div>

              <textarea
                id="lesson-text-input"
                rows={8}
                value={lessonText}
                onChange={(e) => setLessonText(e.target.value)}
                placeholder={t.pasteTextPlaceholder}
                className="w-full p-4 rounded-2xl border border-slate-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 text-slate-900 placeholder:text-slate-400 text-sm leading-relaxed outline-none transition-all resize-y"
              />
              <div className="flex justify-between text-[11px] text-slate-400 px-1">
                <span>
                  {lessonText.trim().split(/\s+/).filter(Boolean).length}{' '}
                  {lang === 'ar' ? 'كلمة' : 'words'}
                </span>
                <span>{lang === 'ar' ? 'يدعم أي لغة ومادة' : 'Supports all subjects'}</span>
              </div>
            </div>
          )}

          {/* Mode 2: Upload Image */}
          {inputMode === 'image' && (
            <div className="space-y-3">
              <input
                type="file"
                ref={fileInputRef}
                accept="image/png,image/jpeg,image/webp,image/jpg"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    processFile(e.target.files[0]);
                  }
                }}
                className="hidden"
              />

              {!imageBase64 ? (
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragOver(true);
                  }}
                  onDragLeave={() => setIsDragOver(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-3xl p-8 sm:p-12 text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-3 ${
                    isDragOver
                      ? 'border-indigo-500 bg-indigo-50/50'
                      : 'border-slate-200 hover:border-indigo-400 hover:bg-slate-50/60'
                  }`}
                >
                  <div className="w-14 h-14 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center shadow-sm">
                    <UploadCloud className="w-7 h-7" />
                  </div>
                  <div className="space-y-1">
                    <p className="font-bold text-slate-800 text-sm sm:text-base">
                      {isDragOver ? t.uploadDragDrop : t.uploadPrompt}
                    </p>
                    <p className="text-xs text-slate-500">{t.uploadSubprompt}</p>
                  </div>
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-700 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-200">
                    {t.uploadSupportedFormats}
                  </span>
                </div>
              ) : (
                <div className="border border-slate-200 rounded-3xl p-4 bg-slate-50/60 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <ImageIcon className="w-4 h-4 text-indigo-600" />
                      <span className="text-xs sm:text-sm font-bold text-slate-800 truncate max-w-xs">
                        {imageFileName || t.uploadedFilePreview}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setImageBase64(null);
                        setImageFileName('');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-red-50 text-red-700 hover:bg-red-100 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>{t.removeUploadedFile}</span>
                    </button>
                  </div>

                  <div className="relative rounded-2xl overflow-hidden max-h-72 border border-slate-200 bg-black/5 flex items-center justify-center">
                    <img
                      src={imageBase64}
                      alt="Uploaded textbook page"
                      className="max-h-72 object-contain"
                    />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Customization Options Grid */}
        <div className="bg-slate-50/90 rounded-2xl p-5 border border-slate-200 space-y-4">
          <h2 className="text-xs sm:text-sm font-bold text-slate-800 flex items-center gap-2">
            <Wand2 className="w-4 h-4 text-indigo-600" />
            <span>{t.settingsSectionTitle}</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Grade Level */}
            <div className="space-y-1.5">
              <label
                htmlFor="grade-level-select"
                className="text-xs font-semibold text-slate-600"
              >
                {t.gradeLevelLabel}
              </label>
              <select
                id="grade-level-select"
                value={gradeLevel}
                onChange={(e) => setGradeLevel(e.target.value as GradeLevel)}
                className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-slate-900 text-xs font-medium focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none"
              >
                <option value="primary">{t.gradePrimary}</option>
                <option value="intermediate">{t.gradeIntermediate}</option>
                <option value="secondary">{t.gradeSecondary}</option>
                <option value="university">{t.gradeUniversity}</option>
                <option value="general">{t.gradeGeneral}</option>
              </select>
            </div>

            {/* Quiz Difficulty */}
            <div className="space-y-1.5">
              <label
                htmlFor="difficulty-select"
                className="text-xs font-semibold text-slate-600"
              >
                {t.quizDifficultyLabel}
              </label>
              <select
                id="difficulty-select"
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as QuizDifficulty)}
                className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-slate-900 text-xs font-medium focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none"
              >
                <option value="easy">{t.diffEasy}</option>
                <option value="medium">{t.diffMedium}</option>
                <option value="hard">{t.diffHard}</option>
              </select>
            </div>

            {/* Question Count */}
            <div className="space-y-1.5">
              <label
                htmlFor="question-count-select"
                className="text-xs font-semibold text-slate-600"
              >
                {t.questionCountLabel}
              </label>
              <select
                id="question-count-select"
                value={questionCount}
                onChange={(e) => setQuestionCount(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-slate-900 text-xs font-medium focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none"
              >
                <option value={3}>3 {lang === 'ar' ? 'أسئلة' : 'Questions'}</option>
                <option value={5}>5 {lang === 'ar' ? 'أسئلة (مثالي)' : 'Questions (Standard)'}</option>
                <option value={10}>10 {lang === 'ar' ? 'أسئلة (شامل)' : 'Questions (Comprehensive)'}</option>
              </select>
            </div>

            {/* Output Language */}
            <div className="space-y-1.5">
              <label
                htmlFor="target-lang-select"
                className="text-xs font-semibold text-slate-600"
              >
                {t.outputLanguageLabel}
              </label>
              <select
                id="target-lang-select"
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value as Language)}
                className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-slate-900 text-xs font-medium focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none"
              >
                <option value="ar">العربية (Arabic)</option>
                <option value="en">English (الإنجليزية)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="p-4 rounded-2xl bg-red-50 border border-red-200 text-red-800 text-xs sm:text-sm flex items-start gap-2.5">
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <p className="font-bold">{t.errorTitle}</p>
              <p className="text-red-700">{errorMessage}</p>
            </div>
          </div>
        )}

        {/* Loading Progress State */}
        {isLoading && (
          <div className="p-6 rounded-2xl bg-indigo-50 border border-indigo-200 space-y-4 animate-in fade-in duration-300">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center animate-spin">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <p className="font-bold text-slate-900 text-sm">
                  {t.analyzingBtn}
                </p>
                <p className="text-xs text-slate-600">
                  {loadingStep === 1 && t.analyzingStep1}
                  {loadingStep === 2 && t.analyzingStep2}
                  {loadingStep === 3 && t.analyzingStep3}
                  {loadingStep === 4 && t.analyzingStep4}
                </p>
              </div>
            </div>

            {/* Step Progress Pills */}
            <div className="grid grid-cols-4 gap-1.5">
              {[1, 2, 3, 4].map((step) => (
                <div
                  key={step}
                  className={`h-2 rounded-full transition-all duration-500 ${
                    loadingStep >= step ? 'bg-indigo-600' : 'bg-slate-200'
                  }`}
                />
              ))}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <button
            type="button"
            onClick={handleClear}
            className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-600 text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t.clearBtn}</span>
          </button>

          <button
            type="submit"
            id="submit-analysis-btn"
            disabled={isLoading}
            className={`px-8 py-3.5 rounded-xl font-bold text-sm sm:text-base flex items-center gap-2 shadow-lg transition-all cursor-pointer ${
              isLoading
                ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-200 hover:shadow-indigo-300 hover:scale-[1.02] active:scale-95'
            }`}
          >
            <Sparkles className="w-5 h-5 text-indigo-200" />
            <span>{isLoading ? t.analyzingBtn : t.analyzeBtn}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
