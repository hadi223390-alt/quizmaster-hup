import React from 'react';
import { BookOpen, Sparkles, PlusCircle, History, Globe, GraduationCap } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n';

interface NavbarProps {
  lang: Language;
  onToggleLang: () => void;
  currentView: 'home' | 'input' | 'lesson' | 'history';
  onNavigate: (view: 'home' | 'input' | 'history') => void;
  hasActiveLesson?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  lang,
  onToggleLang,
  currentView,
  onNavigate,
  hasActiveLesson,
}) => {
  const t = translations[lang];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <button
            id="nav-brand-btn"
            onClick={() => onNavigate('home')}
            className="flex items-center gap-3 text-left rtl:text-right group focus:outline-none cursor-pointer"
          >
            <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform">
              Q
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl sm:text-2xl font-extrabold text-indigo-900 tracking-tight font-sans">
                  QuizMaster Hub
                </span>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                  AI
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                {t.appTagline}
              </p>
            </div>
          </button>

          {/* Navigation Links */}
          <nav className="flex items-center gap-2 sm:gap-4">
            <button
              id="nav-home-btn"
              onClick={() => onNavigate('home')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                currentView === 'home'
                  ? 'bg-indigo-50 text-indigo-700 font-bold border border-indigo-100'
                  : 'text-slate-600 hover:text-indigo-600 hover:bg-slate-50'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span className="hidden sm:inline">{t.navHome}</span>
            </button>

            <button
              id="nav-new-lesson-btn"
              onClick={() => onNavigate('input')}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                currentView === 'input'
                  ? 'bg-indigo-700 text-white shadow-md shadow-indigo-200 ring-2 ring-indigo-300'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-200 hover:shadow-lg'
              }`}
            >
              <PlusCircle className="w-4 h-4 text-indigo-200" />
              <span>{t.navNewLesson}</span>
            </button>

            <button
              id="nav-saved-lessons-btn"
              onClick={() => onNavigate('history')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                currentView === 'history'
                  ? 'bg-indigo-50 text-indigo-700 font-bold border border-indigo-100'
                  : 'text-slate-600 hover:text-indigo-600 hover:bg-slate-50'
              }`}
            >
              <History className="w-4 h-4" />
              <span className="hidden sm:inline">{t.navSavedLessons}</span>
            </button>

            {/* Language Switcher */}
            <div className="h-6 w-px bg-slate-200 mx-1" />

            <button
              id="nav-language-toggle-btn"
              onClick={onToggleLang}
              className="flex items-center gap-2 px-3 py-1.5 border border-slate-200 rounded-full text-xs font-semibold hover:bg-slate-50 transition-all cursor-pointer"
              title="تغيير اللغة / Switch Language"
            >
              <Globe className="w-3.5 h-3.5 text-indigo-600" />
              <span className="text-indigo-600 font-bold">
                {lang === 'ar' ? 'EN' : 'عربي'}
              </span>
              <span className="text-slate-600 font-medium">
                {lang === 'ar' ? 'English' : 'العربية'}
              </span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};
