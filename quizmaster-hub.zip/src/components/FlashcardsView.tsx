import React, { useState } from 'react';
import {
  RotateCcw,
  CheckCircle2,
  Shuffle,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Layers,
  Award,
} from 'lucide-react';
import { Flashcard, Language } from '../types';
import { translations } from '../i18n';

interface FlashcardsViewProps {
  initialFlashcards: Flashcard[];
  lang: Language;
}

export const FlashcardsView: React.FC<FlashcardsViewProps> = ({
  initialFlashcards,
  lang,
}) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';
  const ArrowNext = isRtl ? ArrowLeft : ArrowRight;
  const ArrowPrev = isRtl ? ArrowRight : ArrowLeft;

  const [cards, setCards] = useState<Flashcard[]>(initialFlashcards);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [masteredIds, setMasteredIds] = useState<Set<string>>(new Set());

  if (!cards || cards.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-6">
        <p className="text-slate-500 text-sm">
          {lang === 'ar'
            ? 'لا توجد بطاقات تعليمية متوفرة لهذا الدرس.'
            : 'No flashcards available for this lesson.'}
        </p>
      </div>
    );
  }

  const currentCard = cards[currentIndex];
  const isCurrentMastered = masteredIds.has(currentCard.id || `${currentIndex}`);

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % cards.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + cards.length) % cards.length);
  };

  const toggleMastered = () => {
    const id = currentCard.id || `${currentIndex}`;
    const next = new Set(masteredIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setMasteredIds(next);
  };

  const handleShuffle = () => {
    setIsFlipped(false);
    const shuffled = [...cards].sort(() => Math.random() - 0.5);
    setCards(shuffled);
    setCurrentIndex(0);
  };

  const handleReset = () => {
    setIsFlipped(false);
    setCurrentIndex(0);
    setMasteredIds(new Set());
  };

  const masteredCount = masteredIds.size;
  const progressPercent = Math.round((masteredCount / cards.length) * 100);

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Header & Stats */}
      <div className="flex items-center justify-between bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-900 text-sm">
              {t.flashcardsTitle}
            </span>
            <span className="text-xs text-indigo-700 font-semibold bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full">
              {currentIndex + 1} / {cards.length} {t.cardCount}
            </span>
          </div>
          <p className="text-[11px] text-slate-500">{t.flashcardsSubtitle}</p>
        </div>

        {/* Mastered Counter */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500 font-medium">
            {lang === 'ar' ? 'تم الحفظ:' : 'Mastered:'}
          </span>
          <span className="font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full">
            {masteredCount} / {cards.length} ({progressPercent}%)
          </span>
        </div>
      </div>

      {/* 3D Flashcard Element */}
      <div
        id="flashcard-container"
        onClick={handleFlip}
        className="relative min-h-[300px] sm:min-h-[340px] w-full rounded-3xl cursor-pointer perspective-1000 transition-all select-none group"
      >
        <div
          className={`w-full min-h-[300px] sm:min-h-[340px] rounded-3xl p-8 border transition-all duration-500 flex flex-col justify-between shadow-sm relative ${
            isFlipped
              ? 'bg-indigo-50/70 border-indigo-300 ring-2 ring-indigo-400/20'
              : 'bg-white border-slate-200 hover:border-indigo-300 hover:shadow-md'
          }`}
        >
          {/* Card Top Label */}
          <div className="flex items-center justify-between text-xs">
            <span
              className={`font-bold px-2.5 py-1 rounded-xl text-[11px] ${
                isFlipped
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-100 text-slate-700'
              }`}
            >
              {isFlipped
                ? lang === 'ar'
                  ? '💡 الإجابة والتفسير'
                  : '💡 Answer / Definition'
                : lang === 'ar'
                ? '❓ المفهوم أو السؤال'
                : '❓ Term / Question'}
            </span>

            {isCurrentMastered && (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {t.masteredBadge}
              </span>
            )}
          </div>

          {/* Card Center Content */}
          <div className="py-6 text-center space-y-3 my-auto">
            <p
              className={`text-lg sm:text-xl font-bold leading-relaxed ${
                isFlipped ? 'text-indigo-950' : 'text-slate-900'
              }`}
            >
              {isFlipped ? currentCard.back : currentCard.front}
            </p>
          </div>

          {/* Card Bottom Flip Prompt */}
          <div className="flex items-center justify-between text-xs text-slate-400 border-t border-slate-200/60 pt-3">
            <span>{t.flipCardPrompt}</span>
            <span className="text-[11px] font-mono">
              {currentIndex + 1} / {cards.length}
            </span>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between gap-3">
        <button
          id="flashcard-prev-btn"
          onClick={handlePrev}
          className="px-4 py-2.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
        >
          <ArrowPrev className="w-4 h-4" />
          <span>{t.prevCardBtn}</span>
        </button>

        <button
          id="flashcard-master-btn"
          onClick={toggleMastered}
          className={`px-4 py-2.5 rounded-xl font-semibold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 ${
            isCurrentMastered
              ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>{isCurrentMastered ? t.masteredBadge : t.markMastered}</span>
        </button>

        <button
          id="flashcard-next-btn"
          onClick={handleNext}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-md shadow-indigo-600/20 active:scale-95"
        >
          <span>{t.nextCardBtn}</span>
          <ArrowNext className="w-4 h-4" />
        </button>
      </div>

      {/* Auxiliary Actions (Shuffle, Reset) */}
      <div className="flex items-center justify-center gap-4 text-xs text-slate-500 pt-2">
        <button
          onClick={handleShuffle}
          className="hover:text-indigo-600 transition-colors flex items-center gap-1 cursor-pointer font-medium"
        >
          <Shuffle className="w-3.5 h-3.5" />
          <span>{t.shuffleCardsBtn}</span>
        </button>
        <span>•</span>
        <button
          onClick={handleReset}
          className="hover:text-indigo-600 transition-colors flex items-center gap-1 cursor-pointer font-medium"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{t.resetCardsBtn}</span>
        </button>
      </div>
    </div>
  );
};
