import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  HelpCircle,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Lightbulb,
  Award,
  Clock,
  Eye,
  Check,
} from 'lucide-react';
import { Question, Language } from '../types';
import { translations } from '../i18n';

interface QuizRunnerProps {
  questions: Question[];
  lang: Language;
  onQuizCompleted: (score: number, total: number) => void;
  lessonTitle: string;
}

export const QuizRunner: React.FC<QuizRunnerProps> = ({
  questions,
  lang,
  onQuizCompleted,
  lessonTitle,
}) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';
  const ArrowIcon = isRtl ? ArrowLeft : ArrowRight;

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  
  // History of answers
  const [answers, setAnswers] = useState<
    Array<{
      questionIndex: number;
      selectedOption: number;
      isCorrect: boolean;
    }>
  >([]);

  const [isFinished, setIsFinished] = useState(false);
  const [isReviewMode, setIsReviewMode] = useState(false);
  const [startTime] = useState<number>(Date.now());
  const [timeSpent, setTimeSpent] = useState<string>('');

  const currentQ = questions[currentIndex];
  const totalQuestions = questions.length;

  // Handle option selection
  const handleSelectOption = (index: number) => {
    if (isAnswerChecked) return;
    setSelectedOption(index);
  };

  // Submit/Check Answer
  const handleCheckAnswer = () => {
    if (selectedOption === null) return;
    setIsAnswerChecked(true);
    setShowExplanation(true);

    const isCorrect = selectedOption === currentQ.correctAnswerIndex;
    const newAnswers = [
      ...answers.filter((a) => a.questionIndex !== currentIndex),
      {
        questionIndex: currentIndex,
        selectedOption,
        isCorrect,
      },
    ];
    setAnswers(newAnswers);

    // Minor celebratory burst on correct answer
    if (isCorrect) {
      try {
        confetti({
          particleCount: 30,
          spread: 60,
          origin: { y: 0.8 },
          colors: ['#10B981', '#F59E0B', '#3B82F6'],
        });
      } catch (e) {}
    }
  };

  // Next Question
  const handleNext = () => {
    if (currentIndex < totalQuestions - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedOption(null);
      setIsAnswerChecked(false);
      setShowHint(false);
      setShowExplanation(false);
    } else {
      finishQuiz();
    }
  };

  // Finish Quiz
  const finishQuiz = () => {
    const elapsedSeconds = Math.round((Date.now() - startTime) / 1000);
    const mins = Math.floor(elapsedSeconds / 60);
    const secs = elapsedSeconds % 60;
    setTimeSpent(`${mins}:${secs < 10 ? '0' : ''}${secs}`);

    const correctCount = answers.filter((a) => a.isCorrect).length;
    setIsFinished(true);
    onQuizCompleted(correctCount, totalQuestions);

    const percentage = Math.round((correctCount / totalQuestions) * 100);
    if (percentage >= 70) {
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#F59E0B', '#10B981', '#6366F1', '#EC4899'],
        });
      } catch (e) {}
    }
  };

  // Reset / Retry
  const handleRestart = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswerChecked(false);
    setShowHint(false);
    setShowExplanation(false);
    setAnswers([]);
    setIsFinished(false);
    setIsReviewMode(false);
  };

  const correctAnswersCount = answers.filter((a) => a.isCorrect).length;
  const scorePercent =
    totalQuestions > 0 ? Math.round((correctAnswersCount / totalQuestions) * 100) : 0;

  // Options letter labels
  const optionLetters = isRtl
    ? ['أ', 'ب', 'ج', 'د']
    : ['A', 'B', 'C', 'D'];

  // Score Screen View
  if (isFinished && !isReviewMode) {
    return (
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-10 max-w-2xl mx-auto text-center space-y-6 animate-in zoom-in-95 duration-300 shadow-sm">
        <div className="w-20 h-20 rounded-3xl bg-indigo-50 text-indigo-600 mx-auto flex items-center justify-center shadow-md border border-indigo-100">
          <Award className="w-10 h-10" />
        </div>

        <div className="space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            {t.scoreTitle}
          </h2>
          <p className="text-sm sm:text-base text-slate-600">
            {scorePercent >= 85
              ? t.scoreHighMsg
              : scorePercent >= 60
              ? t.scoreMidMsg
              : t.scoreLowMsg}
          </p>
        </div>

        {/* Score Card Display */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 flex items-center justify-around">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-slate-500">
              {lang === 'ar' ? 'الدرجة' : 'Score'}
            </span>
            <div className="text-3xl sm:text-4xl font-extrabold text-indigo-600">
              {correctAnswersCount} / {totalQuestions}
            </div>
          </div>

          <div className="h-10 w-[1px] bg-slate-200" />

          <div className="space-y-1">
            <span className="text-xs font-semibold text-slate-500">
              {lang === 'ar' ? 'النسبة المئوية' : 'Percentage'}
            </span>
            <div
              className={`text-3xl sm:text-4xl font-extrabold ${
                scorePercent >= 75
                  ? 'text-emerald-600'
                  : scorePercent >= 50
                  ? 'text-indigo-600'
                  : 'text-rose-600'
              }`}
            >
              {scorePercent}%
            </div>
          </div>

          <div className="h-10 w-[1px] bg-slate-200" />

          <div className="space-y-1">
            <span className="text-xs font-semibold text-slate-500">
              {t.timeSpentLabel}
            </span>
            <div className="text-xl sm:text-2xl font-bold text-slate-700 flex items-center justify-center gap-1">
              <Clock className="w-4 h-4 text-slate-400" />
              <span>{timeSpent}</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
          <button
            id="quiz-restart-btn"
            onClick={handleRestart}
            className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm transition-all flex items-center gap-2 shadow-md shadow-indigo-600/20 cursor-pointer active:scale-95"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{t.retryQuizBtn}</span>
          </button>

          <button
            id="quiz-review-btn"
            onClick={() => setIsReviewMode(true)}
            className="px-6 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-sm transition-colors flex items-center gap-2 border border-slate-300 cursor-pointer"
          >
            <Eye className="w-4 h-4" />
            <span>{t.reviewAnswersBtn}</span>
          </button>
        </div>
      </div>
    );
  }

  // Full Review Mode
  if (isReviewMode) {
    return (
      <div className="space-y-6 max-w-3xl mx-auto">
        <div className="flex items-center justify-between bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900">
              {t.reviewAnswersBtn}
            </h2>
            <p className="text-xs text-slate-500">
              {lessonTitle} • {correctAnswersCount}/{totalQuestions} ({scorePercent}%)
            </p>
          </div>
          <button
            id="back-to-score-btn"
            onClick={() => setIsReviewMode(false)}
            className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors cursor-pointer"
          >
            {lang === 'ar' ? 'عرض ملخص النتيجة' : 'Back to Score Summary'}
          </button>
        </div>

        <div className="space-y-4">
          {questions.map((q, qIdx) => {
            const userAns = answers.find((a) => a.questionIndex === qIdx);
            const isUserCorrect = userAns?.isCorrect;

            return (
              <div
                key={q.id || qIdx}
                className={`bg-white rounded-2xl border p-5 space-y-4 transition-all shadow-sm ${
                  isUserCorrect
                    ? 'border-emerald-200'
                    : 'border-rose-200'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5">
                    <span
                      className={`w-7 h-7 rounded-xl font-bold text-xs flex items-center justify-center shrink-0 mt-0.5 ${
                        isUserCorrect
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {qIdx + 1}
                    </span>
                    <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug">
                      {q.question}
                    </h3>
                  </div>

                  <span
                    className={`inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full shrink-0 ${
                      isUserCorrect
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-rose-50 text-rose-700 border border-rose-200'
                    }`}
                  >
                    {isUserCorrect ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        {lang === 'ar' ? 'صحيحة' : 'Correct'}
                      </>
                    ) : (
                      <>
                        <XCircle className="w-3.5 h-3.5" />
                        {lang === 'ar' ? 'خاطئة' : 'Incorrect'}
                      </>
                    )}
                  </span>
                </div>

                {/* Options Review */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {q.options.map((opt, optIdx) => {
                    const isCorrectOpt = optIdx === q.correctAnswerIndex;
                    const isSelectedOpt = userAns?.selectedOption === optIdx;

                    let optBg = 'bg-slate-50 border-slate-200 text-slate-700';
                    if (isCorrectOpt) {
                      optBg = 'bg-emerald-50 border-emerald-300 text-emerald-900 font-semibold';
                    } else if (isSelectedOpt && !isCorrectOpt) {
                      optBg = 'bg-rose-50 border-rose-300 text-rose-900 line-through';
                    }

                    return (
                      <div
                        key={optIdx}
                        className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${optBg}`}
                      >
                        <span className="w-5 h-5 rounded-md bg-white border border-slate-200 flex items-center justify-center font-bold text-[11px] shrink-0">
                          {optionLetters[optIdx]}
                        </span>
                        <span className="flex-1">{opt}</span>
                        {isCorrectOpt && (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        )}
                        {isSelectedOpt && !isCorrectOpt && (
                          <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Explanation */}
                <div className="bg-indigo-50/60 border border-indigo-100 rounded-xl p-3.5 text-xs text-slate-700 space-y-1">
                  <span className="font-bold text-indigo-900 block">
                    💡 {t.explanationLabel}
                  </span>
                  <p className="leading-relaxed">{q.explanation}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // Active Question Runner View
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Progress & Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-3 shadow-sm">
        <div className="flex items-center justify-between text-xs sm:text-sm">
          <div className="flex items-center gap-2">
            <span className="font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 px-3 py-1 rounded-full text-xs">
              {t.questionNumber} {currentIndex + 1} / {totalQuestions}
            </span>
            <span className="text-slate-500 hidden sm:inline truncate max-w-xs">
              {lessonTitle}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {currentQ.hint && !showHint && !isAnswerChecked && (
              <button
                id="quiz-hint-btn"
                onClick={() => setShowHint(true)}
                className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer border border-indigo-100"
              >
                <Lightbulb className="w-3.5 h-3.5 text-indigo-600" />
                <span>{t.hintLabel}</span>
              </button>
            )}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
          <div
            className="bg-indigo-600 h-full rounded-full transition-all duration-300"
            style={{
              width: `${((currentIndex + 1) / totalQuestions) * 100}%`,
            }}
          />
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-sm">
        <h2 className="text-lg sm:text-xl font-bold text-slate-900 leading-relaxed">
          {currentQ.question}
        </h2>

        {/* Hint Box (if revealed) */}
        {showHint && currentQ.hint && (
          <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-3.5 text-xs text-indigo-900 flex items-start gap-2 animate-in fade-in duration-200">
            <Lightbulb className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">{t.hintLabel} </span>
              <span>{currentQ.hint}</span>
            </div>
          </div>
        )}

        {/* Options Grid */}
        <div className="space-y-3">
          {currentQ.options.map((option, idx) => {
            const isSelected = selectedOption === idx;
            const isCorrect = idx === currentQ.correctAnswerIndex;

            let buttonStyle =
              'border-slate-200 hover:border-indigo-300 hover:bg-slate-50 text-slate-800';

            if (isSelected && !isAnswerChecked) {
              buttonStyle =
                'border-indigo-600 bg-indigo-50/70 ring-2 ring-indigo-500/20 text-indigo-950 font-medium';
            } else if (isAnswerChecked) {
              if (isCorrect) {
                buttonStyle =
                  'border-emerald-500 bg-emerald-50/90 text-emerald-950 font-bold ring-2 ring-emerald-500/30';
              } else if (isSelected && !isCorrect) {
                buttonStyle =
                  'border-rose-400 bg-rose-50/90 text-rose-950 line-through';
              } else {
                buttonStyle = 'border-slate-200 opacity-60 text-slate-500';
              }
            }

            return (
              <button
                key={idx}
                id={`quiz-option-${idx}`}
                onClick={() => handleSelectOption(idx)}
                disabled={isAnswerChecked}
                className={`w-full p-4 rounded-2xl border text-right rtl:text-right ltr:text-left transition-all flex items-center justify-between gap-3 text-sm cursor-pointer ${buttonStyle}`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 transition-colors ${
                      isSelected && !isAnswerChecked
                        ? 'bg-indigo-600 text-white'
                        : isAnswerChecked && isCorrect
                        ? 'bg-emerald-600 text-white'
                        : isAnswerChecked && isSelected && !isCorrect
                        ? 'bg-rose-600 text-white'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {optionLetters[idx]}
                  </span>
                  <span className="leading-snug">{option}</span>
                </div>

                {/* State Icons */}
                {isAnswerChecked && isCorrect && (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                )}
                {isAnswerChecked && isSelected && !isCorrect && (
                  <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        {/* Feedback & Explanation Box after checking */}
        {isAnswerChecked && (
          <div
            className={`p-4 sm:p-5 rounded-2xl border text-xs sm:text-sm space-y-2 animate-in fade-in duration-300 ${
              selectedOption === currentQ.correctAnswerIndex
                ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                : 'bg-rose-50/80 border-rose-200 text-rose-950'
            }`}
          >
            <div className="flex items-center gap-2 font-bold text-sm">
              {selectedOption === currentQ.correctAnswerIndex ? (
                <>
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span>{t.correctAnswerAlert}</span>
                </>
              ) : (
                <>
                  <XCircle className="w-5 h-5 text-rose-600" />
                  <span>{t.wrongAnswerAlert}</span>
                </>
              )}
            </div>

            <p className="text-slate-700 leading-relaxed pt-1">
              <strong className="font-bold text-slate-900">
                {t.explanationLabel}{' '}
              </strong>
              {currentQ.explanation}
            </p>
          </div>
        )}

        {/* Action Controls */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
          <div className="text-xs text-slate-500">
            {selectedOption === null
              ? lang === 'ar'
                ? 'اختر إجابة للمتابعة'
                : 'Select an option to continue'
              : ''}
          </div>

          <div>
            {!isAnswerChecked ? (
              <button
                id="quiz-check-btn"
                onClick={handleCheckAnswer}
                disabled={selectedOption === null}
                className={`px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                  selectedOption !== null
                    ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-600/20'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                {t.checkAnswerBtn}
              </button>
            ) : (
              <button
                id="quiz-next-btn"
                onClick={handleNext}
                className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-md shadow-indigo-600/20 transition-all cursor-pointer active:scale-95"
              >
                <span>
                  {currentIndex < totalQuestions - 1
                    ? t.nextQuestionBtn
                    : t.finishQuizBtn}
                </span>
                <ArrowIcon className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
