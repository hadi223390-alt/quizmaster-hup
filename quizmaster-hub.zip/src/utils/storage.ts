import { SavedLesson, Language } from '../types';

const STORAGE_KEY_LESSONS = 'quizmaster_saved_lessons_v1';
const STORAGE_KEY_LANG = 'quizmaster_lang_pref_v1';

export function getSavedLessons(): SavedLesson[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_LESSONS);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading saved lessons:', e);
    return [];
  }
}

export function saveLesson(lesson: SavedLesson): void {
  try {
    const current = getSavedLessons();
    const existingIndex = current.findIndex((l) => l.id === lesson.id);
    let updated: SavedLesson[];
    if (existingIndex >= 0) {
      updated = [...current];
      updated[existingIndex] = lesson;
    } else {
      updated = [lesson, ...current];
    }
    localStorage.setItem(STORAGE_KEY_LESSONS, JSON.stringify(updated));
  } catch (e) {
    console.error('Error saving lesson:', e);
  }
}

export function deleteSavedLesson(id: string): void {
  try {
    const current = getSavedLessons();
    const filtered = current.filter((l) => l.id !== id);
    localStorage.setItem(STORAGE_KEY_LESSONS, JSON.stringify(filtered));
  } catch (e) {
    console.error('Error deleting lesson:', e);
  }
}

export function updateLessonQuizScore(
  lessonId: string,
  score: number,
  total: number
): void {
  try {
    const lessons = getSavedLessons();
    const target = lessons.find((l) => l.id === lessonId);
    if (!target) return;

    const percentage = Math.round((score / total) * 100);
    const newCount = (target.quizCompletedCount || 0) + 1;
    const newHigh = Math.max(target.quizHighScore || 0, percentage);

    target.quizCompletedCount = newCount;
    target.quizHighScore = newHigh;
    target.lastQuizScore = {
      score,
      total,
      percentage,
      date: new Date().toLocaleDateString(),
    };

    saveLesson(target);
  } catch (e) {
    console.error('Error updating quiz score:', e);
  }
}

export function getSavedLanguage(): Language {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_LANG);
    if (saved === 'en' || saved === 'ar') return saved;
    return 'ar'; // Default to Arabic as requested
  } catch {
    return 'ar';
  }
}

export function saveLanguagePreference(lang: Language): void {
  try {
    localStorage.setItem(STORAGE_KEY_LANG, lang);
  } catch (e) {
    console.error('Error saving language preference:', e);
  }
}
